
# intrum-woocommerce-gateway

Intrum payment Woocommerce plugin

## Setup

The plugin is using [Wordpress Rest API](https://developer.wordpress.org/rest-api/using-the-rest-api/), so selected [Permalinks](https://codex.wordpress.org/Using_Permalinks#Choosing_your_permalink_structure) style should be "Post name". [More information](https://github.com/WP-API/WP-API/issues/69). 

After installing the plugin please copy the folder `woocommerce` to `wp-content/themes/`*`yourtheme`*`/` to ensure that the plugin works correctly.

State: development
